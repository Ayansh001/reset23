
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Quote, Heart } from 'lucide-react';
import { useMotivationalQuotes } from '@/hooks/useMotivationalQuotes';
import { useState } from 'react';

export function QuotePreferencesPanel() {
  const { preferences, updatePreferences, categories } = useMotivationalQuotes();
  const [favorites, setFavorites] = useState(() => {
    return JSON.parse(localStorage.getItem('favorite_quotes') || '[]');
  });

  const handleFrequencyChange = (frequency: typeof preferences.frequency) => {
    updatePreferences({ frequency });
  };

  const handleCategoryToggle = (category: string) => {
    const newCategories = preferences.categories.includes(category as any)
      ? preferences.categories.filter(c => c !== category)
      : [...preferences.categories, category as any];
    
    updatePreferences({ categories: newCategories });
  };

  const clearFavorites = () => {
    localStorage.removeItem('favorite_quotes');
    setFavorites([]);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Quote className="h-5 w-5" />
            Motivational Quotes
          </CardTitle>
          <CardDescription>
            Get inspired with motivational quotes during your study sessions
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Frequency Settings */}
          <div className="space-y-3">
            <Label className="text-sm font-medium">Quote Frequency</Label>
            <div className="grid grid-cols-2 gap-3">
              {(['off', 'low', 'medium', 'high'] as const).map((freq) => (
                <Button
                  key={freq}
                  variant={preferences.frequency === freq ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => handleFrequencyChange(freq)}
                  className="justify-start capitalize"
                >
                  {freq}
                </Button>
              ))}
            </div>
          </div>

          {/* Category Preferences */}
          {preferences.frequency !== 'off' && (
            <div className="space-y-3">
              <Label className="text-sm font-medium">Preferred Categories</Label>
              <div className="flex flex-wrap gap-2">
                {categories.map((category) => (
                  <Badge
                    key={category}
                    variant={preferences.categories.includes(category) ? 'default' : 'outline'}
                    className="cursor-pointer capitalize"
                    onClick={() => handleCategoryToggle(category)}
                  >
                    {category.replace('_', ' ')}
                  </Badge>
                ))}
              </div>
              <p className="text-xs text-muted-foreground">
                Click categories to toggle your preferences
              </p>
            </div>
          )}

          {/* Favorite Quotes */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-sm font-medium">
                Favorite Quotes ({favorites.length})
              </Label>
              {favorites.length > 0 && (
                <Button variant="ghost" size="sm" onClick={clearFavorites}>
                  Clear All
                </Button>
              )}
            </div>
            
            {favorites.length === 0 ? (
              <p className="text-sm text-muted-foreground">
                Save quotes by clicking the 💝 Save button when they appear
              </p>
            ) : (
              <div className="max-h-48 overflow-y-auto space-y-2">
                {favorites.map((quote: any) => (
                  <div
                    key={quote.id}
                    className="p-3 rounded-lg border bg-muted/30 text-sm"
                  >
                    <div className="font-medium mb-1">"{quote.text}"</div>
                    <div className="text-muted-foreground">— {quote.author}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
