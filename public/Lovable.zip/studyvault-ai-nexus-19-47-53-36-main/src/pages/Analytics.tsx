
import { LearningDashboard } from '@/components/analytics/LearningDashboard';

export default function Analytics() {
  return (
    <div className="container mx-auto px-4 py-6">
      <LearningDashboard />
    </div>
  );
}
