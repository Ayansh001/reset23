import { AIHistoryDashboard } from '@/features/ai/components/AIHistoryDashboard';

export default function AIHistory() {
  return <AIHistoryDashboard />;
}