
import { OCRDashboard } from '@/features/ocr/components/OCRDashboard';

export default function OCR() {
  return <OCRDashboard />;
}
