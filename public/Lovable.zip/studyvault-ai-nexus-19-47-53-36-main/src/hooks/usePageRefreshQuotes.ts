import { useEffect, useCallback, useState } from 'react';
import { useAuth } from '@/features/auth/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useNotifications } from '@/hooks/useNotifications';

interface DailyQuote {
  id: string;
  quote_text: string;
  category: string;
  ai_service: string;
  model_used: string;
  is_read: boolean;
}

export function usePageRefreshQuotes() {
  const { user } = useAuth();
  const { createNotification } = useNotifications();
  const [quotes, setQuotes] = useState<DailyQuote[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [lastFetchDate, setLastFetchDate] = useState<string>('');

  const generateQuotes = useCallback(async () => {
    if (!user) return;

    setIsLoading(true);
    try {
      console.log('Generating quotes for user:', user.id);
      
      const { data, error } = await supabase.functions.invoke('ai-quote-generator', {
        body: { userId: user.id },
      });

      if (error) {
        console.error('Error generating quotes:', error);
        toast.error('Failed to generate quotes - please try again later');
        return;
      }

      console.log('Quote generation result:', data);
      
      if (data?.success) {
        // Fetch the newly generated quotes
        await fetchTodaysQuotes();
        
        if (data.type === 'ai') {
          toast.success(`✨ Generated ${data.quotesGenerated} AI-powered quotes for you!`);
        } else if (data.type === 'fallback') {
          toast.info(`📝 Prepared ${data.quotesGenerated} motivational quotes for you!`);
        } else {
          toast.info('Your daily quotes are ready!');
        }
      } else {
        console.error('Quote generation failed:', data);
        toast.error('Quote generation failed - using offline quotes');
      }
    } catch (error) {
      console.error('Error in quote generation:', error);
      toast.error('Unable to generate quotes - please check your connection');
    } finally {
      setIsLoading(false);
    }
  }, [user]);

  const fetchTodaysQuotes = useCallback(async () => {
    if (!user) return;

    try {
      const today = new Date().toISOString().split('T')[0];
      
      // First try to get unread quotes for today
      const { data: unreadData, error: unreadError } = await supabase
        .from('ai_daily_quotes')
        .select('*')
        .eq('user_id', user.id)
        .eq('generated_date', today)
        .eq('is_read', false)
        .order('created_at', { ascending: true });

      if (unreadError) {
        console.error('Error fetching unread quotes:', unreadError);
      }

      // If we have unread quotes, use them
      if (unreadData && unreadData.length > 0) {
        setQuotes(unreadData);
        setLastFetchDate(today);
        console.log(`Loaded ${unreadData.length} unread quotes for today`);
        return;
      }

      // If no unread quotes, check if we have any quotes for today
      const { data: allData, error: allError } = await supabase
        .from('ai_daily_quotes')
        .select('*')
        .eq('user_id', user.id)
        .eq('generated_date', today)
        .order('created_at', { ascending: true });

      if (allError) {
        console.error('Error fetching all quotes:', allError);
        toast.error('Unable to load your daily quotes');
        return;
      }

      if (allData && allData.length > 0) {
        // All quotes are read, but we have them for today
        console.log(`All ${allData.length} quotes for today have been read`);
        setQuotes(allData);
        setLastFetchDate(today);
      } else {
        console.log('No quotes found for today, generating...');
        await generateQuotes();
      }
    } catch (error) {
      console.error('Error fetching quotes:', error);
      toast.error('Unable to load quotes - please refresh the page');
    }
  }, [user, generateQuotes]);

  const markQuoteAsRead = useCallback(async (quoteId: string) => {
    try {
      const { error } = await supabase
        .from('ai_daily_quotes')
        .update({ is_read: true, updated_at: new Date().toISOString() })
        .eq('id', quoteId);

      if (error) {
        console.error('Error marking quote as read:', error);
      } else {
        console.log('Quote marked as read:', quoteId);
      }
    } catch (error) {
      console.error('Error marking quote as read:', error);
    }
  }, []);

  const showNextQuote = useCallback(async () => {
    // Only show unread quotes
    const unreadQuotes = quotes.filter(q => !q.is_read);
    if (unreadQuotes.length === 0) {
      console.log('No unread quotes available');
      return;
    }

    const quote = unreadQuotes[0]; // Always show the first unread quote
    if (!quote) return;

    const isAIGenerated = quote.ai_service !== 'fallback';
    const icon = isAIGenerated ? '🤖' : '💫';
    const source = isAIGenerated ? `AI ${quote.ai_service}` : 'Curated';

    // Create notification for this quote
    try {
      await createNotification({
        type: 'daily_quote',
        title: 'Daily Motivation',
        message: quote.quote_text,
        data: {
          quote_id: quote.id,
          category: quote.category,
          source: source,
          ai_service: quote.ai_service
        }
      });
      console.log('Created notification for quote:', quote.id);
    } catch (error) {
      console.error('Failed to create notification for quote:', error);
    }

    // Show toast
    toast.success(quote.quote_text, {
      description: `${icon} ${source} • ${quote.category}`,
      duration: 6000,
      action: {
        label: '💝 Save',
        onClick: () => {
          const favorites = JSON.parse(localStorage.getItem('favorite_quotes') || '[]');
          const favoriteQuote = {
            id: quote.id,
            text: quote.quote_text,
            author: `${source} Quote`,
            category: quote.category
          };
          
          if (!favorites.some((fav: any) => fav.id === quote.id)) {
            favorites.push(favoriteQuote);
            localStorage.setItem('favorite_quotes', JSON.stringify(favorites));
            toast.success('Quote saved to favorites!', { duration: 2000 });
          }
        }
      },
      className: isAIGenerated 
        ? 'border-l-4 border-l-purple-500'
        : 'border-l-4 border-l-blue-500'
    });

    // Mark as read
    await markQuoteAsRead(quote.id);

    // Update quote state to mark as read
    setQuotes(prev => prev.map(q => 
      q.id === quote.id ? { ...q, is_read: true } : q
    ));
  }, [quotes, createNotification, markQuoteAsRead]);

  // Initialize quotes on user login or page load
  useEffect(() => {
    if (user) {
      fetchTodaysQuotes();
    }
  }, [user, fetchTodaysQuotes]);

  // Daily refresh mechanism - check if date changed
  useEffect(() => {
    if (!user || !lastFetchDate) return;

    const today = new Date().toISOString().split('T')[0];
    if (lastFetchDate !== today) {
      console.log('Date changed, refreshing quotes...');
      fetchTodaysQuotes();
    }
  }, [user, lastFetchDate, fetchTodaysQuotes]);

  // Show first quote automatically when unread quotes are loaded
  useEffect(() => {
    const unreadQuotes = quotes.filter(q => !q.is_read);
    if (unreadQuotes.length > 0) {
      // Small delay to let the page load
      const timer = setTimeout(() => {
        showNextQuote();
      }, 2000);
      
      return () => clearTimeout(timer);
    }
  }, [quotes, showNextQuote]);

  return {
    quotes,
    isLoading,
    showNextQuote,
    generateQuotes,
    hasQuotes: quotes.length > 0,
    unreadQuotes: quotes.filter(q => !q.is_read).length,
    hasUnreadQuotes: quotes.filter(q => !q.is_read).length > 0
  };
}