
import { useActivityTracker } from './useActivityTracker';
import { useMotivationalQuotes } from './useMotivationalQuotes';
import { useCallback } from 'react';

export function useEnhancedActivityTracker() {
  const activityTracker = useActivityTracker();
  const quotes = useMotivationalQuotes();

  const trackNoteCreatedWithQuote = useCallback((noteData: { id: string; title: string; wordCount?: number }) => {
    activityTracker.trackNoteCreated(noteData);
    
    // Show quote for significant notes (100+ words)
    if ((noteData.wordCount || 0) >= 100) {
      quotes.triggerActivityQuote();
    }
  }, [activityTracker, quotes]);

  const trackFileUploadedWithQuote = useCallback((fileData: { id: string; name: string; type: string; size: number }) => {
    activityTracker.trackFileUploaded(fileData);
    quotes.triggerActivityQuote();
  }, [activityTracker, quotes]);

  return {
    ...activityTracker,
    trackNoteCreated: trackNoteCreatedWithQuote,
    trackFileUploaded: trackFileUploadedWithQuote
  };
}
