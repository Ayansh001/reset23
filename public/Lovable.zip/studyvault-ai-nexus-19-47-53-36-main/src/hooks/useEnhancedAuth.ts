
import { useAuth } from '@/features/auth/hooks/useAuth';
import { useMotivationalQuotes } from './useMotivationalQuotes';
import { useCallback, useEffect, useRef } from 'react';

export function useEnhancedAuth() {
  const auth = useAuth();
  const quotes = useMotivationalQuotes();
  const hasShownLoginQuote = useRef(false);
  const loginTimeoutRef = useRef<NodeJS.Timeout>();

  // Trigger welcome quote on successful login
  useEffect(() => {
    // Clear any existing timeout
    if (loginTimeoutRef.current) {
      clearTimeout(loginTimeoutRef.current);
      loginTimeoutRef.current = undefined;
    }

    // Legacy quote system disabled to prevent conflicts with AI quote system
    // The new usePageRefreshQuotes hook handles all quote display now
    
    // Reset flag when user logs out
    if (!auth.user) {
      hasShownLoginQuote.current = false;
      if (loginTimeoutRef.current) {
        clearTimeout(loginTimeoutRef.current);
        loginTimeoutRef.current = undefined;
      }
    }
  }, [auth.user?.id, quotes]); // Use user.id instead of user to avoid re-triggering on user object changes

  // Cleanup timeout on unmount
  useEffect(() => {
    return () => {
      if (loginTimeoutRef.current) {
        clearTimeout(loginTimeoutRef.current);
      }
    };
  }, []);

  return {
    ...auth,
    quotes
  };
}
