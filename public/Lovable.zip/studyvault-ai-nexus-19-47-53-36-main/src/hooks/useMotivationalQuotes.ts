
import { useCallback, useEffect, useState } from 'react';
import { toast } from 'sonner';
import { useAuth } from '@/features/auth/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { motivationalQuoteService, Quote, QuoteTrigger } from '@/services/MotivationalQuoteService';

interface QuoteToastOptions {
  showAuthor?: boolean;
  showCategory?: boolean;
  duration?: number;
  showSaveAction?: boolean;
}

export function useMotivationalQuotes() {
  const { user } = useAuth();
  const [preferences, setPreferences] = useState(motivationalQuoteService.getPreferences());
  const [aiQuotes, setAiQuotes] = useState<any[]>([]);

  const getTimeOfDay = (): 'morning' | 'afternoon' | 'evening' => {
    const hour = new Date().getHours();
    if (hour < 12) return 'morning';
    if (hour < 18) return 'afternoon';
    return 'evening';
  };

  // Fetch AI quotes for fallback
  useEffect(() => {
    if (user) {
      fetchAIQuotes();
    }
  }, [user]);

  const fetchAIQuotes = useCallback(async () => {
    if (!user) return;

    try {
      const today = new Date().toISOString().split('T')[0];
      const { data } = await supabase
        .from('ai_daily_quotes')
        .select('*')
        .eq('user_id', user.id)
        .eq('generated_date', today)
        .eq('is_read', false)
        .limit(5);

      if (data) {
        setAiQuotes(data);
      }
    } catch (error) {
      console.error('Error fetching AI quotes:', error);
    }
  }, [user]);

  const showQuoteToast = useCallback((trigger: QuoteTrigger, options: QuoteToastOptions = {}) => {
    // Try AI quotes first if available
    if (aiQuotes.length > 0) {
      const aiQuote = aiQuotes[Math.floor(Math.random() * aiQuotes.length)];
      const isAIGenerated = aiQuote.ai_service !== 'fallback';
      
      const {
        showAuthor = true,
        showCategory = false,
        duration = 6000,
        showSaveAction = false
      } = options;

      toast.success(aiQuote.quote_text, {
        description: showAuthor ? `🤖 ${isAIGenerated ? 'AI Generated' : 'Curated'} • ${aiQuote.category}` : undefined,
        duration,
        action: showSaveAction ? {
          label: '💝 Save',
          onClick: () => {
            const favorites = JSON.parse(localStorage.getItem('favorite_quotes') || '[]');
            const favoriteQuote = {
              id: aiQuote.id,
              text: aiQuote.quote_text,
              author: `${isAIGenerated ? 'AI' : 'Curated'} Quote`,
              category: aiQuote.category
            };
            
            if (!favorites.some((fav: any) => fav.id === aiQuote.id)) {
              favorites.push(favoriteQuote);
              localStorage.setItem('favorite_quotes', JSON.stringify(favorites));
              toast.success('Quote saved to favorites!', { duration: 2000 });
            }
          }
        } : undefined,
        className: isAIGenerated 
          ? 'border-l-4 border-l-purple-500'
          : 'border-l-4 border-l-blue-500'
      });

      // Mark AI quote as read
      if (user) {
        supabase
          .from('ai_daily_quotes')
          .update({ is_read: true })
          .eq('id', aiQuote.id)
          .then(() => {
            // Remove from available AI quotes
            setAiQuotes(prev => prev.filter(q => q.id !== aiQuote.id));
          });
      }
      
      return;
    }

    // Fall back to static quotes
    const quote = motivationalQuoteService.getQuoteForTrigger(trigger, getTimeOfDay());
    
    if (!quote) return;

    const {
      showAuthor = true,
      showCategory = false,
      duration = 6000,
      showSaveAction = false
    } = options;

    toast.success(quote.text, {
      description: showAuthor ? `📝 ${quote.author} • static` : undefined,
      duration,
      action: showSaveAction ? {
        label: '💝 Save',
        onClick: () => {
          const favorites = JSON.parse(localStorage.getItem('favorite_quotes') || '[]');
          if (!favorites.some((fav: Quote) => fav.id === quote.id)) {
            favorites.push(quote);
            localStorage.setItem('favorite_quotes', JSON.stringify(favorites));
            toast.success('Quote saved to favorites!', { duration: 2000 });
          }
        }
      } : undefined,
      className: 'border-l-4 border-l-blue-500'
    });
  }, []);

  const triggerSessionStartQuote = useCallback(() => {
    showQuoteToast('session_start', { 
      showSaveAction: true,
      duration: 8000 
    });
  }, [showQuoteToast, aiQuotes]);

  const triggerSessionEndQuote = useCallback(() => {
    showQuoteToast('session_end', { 
      showSaveAction: true,
      duration: 6000 
    });
  }, [showQuoteToast]);

  const triggerMilestoneQuote = useCallback(() => {
    showQuoteToast('milestone', { 
      showSaveAction: true,
      duration: 7000 
    });
  }, [showQuoteToast]);

  const triggerBreakTimeQuote = useCallback(() => {
    showQuoteToast('break_time', { 
      duration: 5000 
    });
  }, [showQuoteToast]);

  const triggerActivityQuote = useCallback(() => {
    // Only show occasionally for activities to avoid spam
    if (Math.random() > 0.7) {
      showQuoteToast('activity_completed', { 
        duration: 4000 
      });
    }
  }, [showQuoteToast]);

  const updatePreferences = useCallback((newPreferences: Partial<typeof preferences>) => {
    motivationalQuoteService.savePreferences(newPreferences);
    setPreferences({ ...preferences, ...newPreferences });
  }, [preferences]);

  return {
    triggerSessionStartQuote,
    triggerSessionEndQuote,
    triggerMilestoneQuote,
    triggerBreakTimeQuote,
    triggerActivityQuote,
    preferences,
    updatePreferences,
    categories: motivationalQuoteService.getCategories(),
    aiQuotes,
    fetchAIQuotes
  };
}
