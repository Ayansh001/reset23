import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Drawer, DrawerContent, DrawerDescription, DrawerHeader, DrawerTitle, DrawerTrigger } from '@/components/ui/drawer';
import { BookOpen, Brain, Lightbulb, MessageSquare, Map, Network, Video, Target, Sparkles, Loader2, Youtube, ZoomIn, ZoomOut, RotateCcw, Flashlight } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/features/auth/hooks/useAuth';
import { toast } from 'sonner';

interface GeminiConceptLearnerProps {
  initialConcept?: string;
}

interface ConceptExplanation {
  concept: string;
  explanation: string;
  keyPoints: string[];
  studyTips: string[];
  examples: string[];
  relatedConcepts: Array<{
    name: string;
    relationship: string;
  }>;
  mindMap: {
    center: string;
    branches: Array<{
      topic: string;
      subtopics: string[];
    }>;
  };
  knowledgeGraph: {
    centralNode: string;
    connectedNodes: string[];
  };
  youtubeSearchQuery: string;
  youtubeVideos?: Array<{
    id: string;
    title: string;
    thumbnail: string;
    channel: string;
    description: string;
    embedId: string;
  }>;
}

export function GeminiConceptLearner({ initialConcept = '' }: GeminiConceptLearnerProps) {
  const { user } = useAuth();
  const [concept, setConcept] = useState(initialConcept);
  const [explanation, setExplanation] = useState<ConceptExplanation | null>(null);
  const [isLearning, setIsLearning] = useState(false);
  const [loadingVideos, setLoadingVideos] = useState(false);
  const [knowledgeGraphZoom, setKnowledgeGraphZoom] = useState(1);
  const [selectedText, setSelectedText] = useState('');
  const [currentFlashcard, setCurrentFlashcard] = useState(0);
  const [showFlashcardAnswer, setShowFlashcardAnswer] = useState(false);

  const learnConcept = async () => {
    if (!concept.trim() || !user) {
      toast.error('Please enter a concept to learn');
      return;
    }
    
    setIsLearning(true);
    try {
      // Call Gemini concept learner
      const { data, error } = await supabase.functions.invoke('gemini-concept-learner-v2', {
        body: { concept: concept.trim() }
      });

      if (error) {
        throw new Error(error.message);
      }

      if (data?.success && data?.result) {
        setExplanation(data.result);
        toast.success('Concept explanation generated!');
        
        // Fetch YouTube videos using the search query
        if (data.result.youtubeSearchQuery) {
          await fetchYouTubeVideos(data.result.youtubeSearchQuery);
        }
      } else {
        throw new Error('Failed to get concept explanation');
      }
    } catch (err: any) {
      console.error('Gemini concept learning error:', err);
      toast.error('Concept learning failed', {
        description: err.message || 'Please try again'
      });
    } finally {
      setIsLearning(false);
    }
  };

  const fetchYouTubeVideos = async (searchQuery: string) => {
    setLoadingVideos(true);
    try {
      const { data, error } = await supabase.functions.invoke('youtube-search-handler', {
        body: { query: searchQuery, maxResults: 3 }
      });

      if (error) {
        console.error('YouTube search error:', error);
        return;
      }

      if (data?.success && data?.videos) {
        setExplanation(prev => prev ? { ...prev, youtubeVideos: data.videos } : null);
      }
    } catch (err) {
      console.error('YouTube search failed:', err);
    } finally {
      setLoadingVideos(false);
    }
  };

  const exploreRelatedConcept = (relatedConcept: string) => {
    setConcept(relatedConcept);
    setExplanation(null);
  };

  const handleTextSelection = () => {
    const selection = window.getSelection();
    const text = selection?.toString().trim();
    if (text && text.length > 3) {
      setSelectedText(text);
    }
  };

  const createFlashcardsFromStudyTips = () => {
    if (!explanation?.studyTips) return [];
    
    return explanation.studyTips.map((tip, index) => ({
      front: `Study Strategy ${index + 1}`,
      back: tip,
      concept: explanation.concept
    }));
  };

  const handleFlashcardNext = () => {
    const flashcards = createFlashcardsFromStudyTips();
    setCurrentFlashcard((prev) => (prev + 1) % flashcards.length);
    setShowFlashcardAnswer(false);
  };

  const handleFlashcardPrev = () => {
    const flashcards = createFlashcardsFromStudyTips();
    setCurrentFlashcard((prev) => (prev - 1 + flashcards.length) % flashcards.length);
    setShowFlashcardAnswer(false);
  };

  const renderMindMap = () => {
    if (!explanation?.mindMap) return null;

    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Map className="h-5 w-5 text-indigo-500" />
            🗺️ Mind Map Structure
          </CardTitle>
          <CardDescription>
            A mind map helps you break down the topic visually so you can revise and understand more effectively.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center space-y-6">
            {/* Center concept */}
            <div className="bg-gradient-to-r from-primary to-primary/80 text-primary-foreground px-6 py-4 rounded-xl font-semibold text-lg shadow-lg border">
              {explanation.mindMap.center}
            </div>
            
            {/* Branches */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 w-full">
              {explanation.mindMap.branches.map((branch, index) => (
                <div key={index} className="relative">
                  {/* Connection line */}
                  <div className="absolute -top-3 left-1/2 w-0.5 h-6 bg-primary/40 transform -translate-x-1/2"></div>
                  
                  <div className="bg-gradient-to-br from-secondary/80 to-secondary/60 backdrop-blur-sm rounded-lg p-4 border shadow-sm">
                    <h4 className="font-semibold text-center mb-3 text-foreground text-sm uppercase tracking-wide">
                      🔹 {branch.topic}
                    </h4>
                    <div className="space-y-2">
                      {branch.subtopics.map((subtopic, subIndex) => (
                        <div key={subIndex} className="bg-background rounded-md px-3 py-2 text-sm text-center border border-border/50 hover:border-primary/30 transition-colors">
                          {subtopic}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  const renderKnowledgeGraph = () => {
    if (!explanation?.knowledgeGraph) return null;

    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Network className="h-5 w-5 text-emerald-500" />
            🌐 Knowledge Graph Overview
          </CardTitle>
          <CardDescription>
            🧠 A knowledge graph shows how this topic is connected to other important concepts.
          </CardDescription>
          <div className="flex gap-2 mt-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setKnowledgeGraphZoom(prev => Math.min(prev + 0.2, 2))}
              className="h-8"
            >
              <ZoomIn className="h-3 w-3" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setKnowledgeGraphZoom(prev => Math.max(prev - 0.2, 0.5))}
              className="h-8"
            >
              <ZoomOut className="h-3 w-3" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setKnowledgeGraphZoom(1)}
              className="h-8"
            >
              <RotateCcw className="h-3 w-3" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="relative h-96 bg-gradient-to-br from-emerald-50/30 to-blue-50/20 dark:from-emerald-950/20 dark:to-blue-950/10 rounded-lg overflow-hidden border">
            <div 
              className="absolute inset-0 transition-transform duration-300"
              style={{ transform: `scale(${knowledgeGraphZoom})` }}
            >
              {/* Central Node */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="bg-gradient-to-r from-emerald-500 to-emerald-600 text-white px-6 py-3 rounded-xl font-semibold text-lg shadow-lg z-10 border-2 border-emerald-300">
                  {explanation.knowledgeGraph.centralNode}
                </div>
              </div>
              
              {/* Connected Nodes */}
              {explanation.knowledgeGraph.connectedNodes.map((node, index) => {
                const angle = (index * 360) / explanation.knowledgeGraph.connectedNodes.length;
                const radius = 140;
                const x = Math.cos((angle * Math.PI) / 180) * radius;
                const y = Math.sin((angle * Math.PI) / 180) * radius;

                return (
                  <div key={index} className="absolute">
                    {/* Connection line */}
                    <svg className="absolute inset-0 w-full h-full pointer-events-none" style={{ zIndex: 1 }}>
                      <line
                        x1="50%"
                        y1="50%"
                        x2={`calc(50% + ${x}px)`}
                        y2={`calc(50% + ${y}px)`}
                        stroke="hsl(var(--emerald-500))"
                        strokeWidth="2"
                        strokeDasharray="8,4"
                        opacity="0.7"
                      />
                    </svg>
                    
                    {/* Node */}
                    <div
                      className="absolute transform -translate-x-1/2 -translate-y-1/2 bg-gradient-to-r from-secondary to-secondary/80 text-secondary-foreground px-4 py-2 rounded-lg text-sm font-medium shadow-sm border cursor-pointer hover:from-secondary/80 hover:to-secondary/60 transition-all z-10"
                      style={{
                        left: `calc(50% + ${x}px)`,
                        top: `calc(50% + ${y}px)`,
                      }}
                      onClick={() => exploreRelatedConcept(node)}
                    >
                      {node}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  const renderYouTubeVideos = () => {
    if (loadingVideos) {
      return (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Youtube className="h-5 w-5 text-red-500" />
              🎥 YouTube Learning Videos
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-center h-32">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
              <span className="ml-2 text-muted-foreground">Finding the best educational videos...</span>
            </div>
          </CardContent>
        </Card>
      );
    }

    if (!explanation?.youtubeVideos || explanation.youtubeVideos.length === 0) {
      return (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Youtube className="h-5 w-5 text-red-500" />
              🎥 YouTube Learning Videos
            </CardTitle>
            <CardDescription>
              🎬 You can watch the best YouTube tutorials right here to reinforce your understanding.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground text-center py-8">
              No videos found for this concept. Try searching manually on YouTube.
            </p>
          </CardContent>
        </Card>
      );
    }

    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Youtube className="h-5 w-5 text-red-500" />
            🎥 YouTube Learning Videos
          </CardTitle>
          <CardDescription>
            🎬 You can watch the best YouTube tutorials right here to reinforce your understanding.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {explanation.youtubeVideos.map((video, index) => (
              <div key={video.id} className="border rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
                <div className="aspect-video">
                  <iframe
                    src={`https://www.youtube.com/embed/${video.embedId}`}
                    title={video.title}
                    className="w-full h-full"
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  ></iframe>
                </div>
                <div className="p-3">
                  <h4 className="font-medium text-sm mb-2 line-clamp-2">{video.title}</h4>
                  <p className="text-xs text-muted-foreground mb-2">📺 {video.channel}</p>
                  <p className="text-xs text-muted-foreground line-clamp-2">{video.description}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="w-full max-w-6xl mx-auto space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5 text-primary" />
            Gemini Concept Learner
            <Badge variant="outline" className="ml-2">Gemini 2.0</Badge>
          </CardTitle>
          <CardDescription>
            Enter any concept you want to understand and learn about using Google's Gemini AI
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Input
              placeholder="Enter a concept to learn (e.g., Machine Learning, Photosynthesis, Democracy)"
              value={concept}
              onChange={(e) => setConcept(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && learnConcept()}
              className="flex-1"
            />
            <Button 
              onClick={learnConcept} 
              disabled={!concept.trim() || isLearning}
              className="min-w-[100px]"
            >
              {isLearning ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Learn'}
            </Button>
          </div>
        </CardContent>
      </Card>

      {explanation && (
        <div className="space-y-6">
          <Tabs defaultValue="explanation" className="w-full">
            <TabsList className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-1 h-auto p-2 bg-muted/50">
              <TabsTrigger value="explanation" className="text-xs sm:text-sm px-2 py-1.5">📘 Explanation</TabsTrigger>
              <TabsTrigger value="keypoints" className="text-xs sm:text-sm px-2 py-1.5">🔑 Key Points</TabsTrigger>
              <TabsTrigger value="tips" className="text-xs sm:text-sm px-2 py-1.5">🎯 Study Tips</TabsTrigger>
              <TabsTrigger value="examples" className="text-xs sm:text-sm px-2 py-1.5">📚 Examples</TabsTrigger>
              <TabsTrigger value="related" className="text-xs sm:text-sm px-2 py-1.5">🔍 Related</TabsTrigger>
              <TabsTrigger value="mindmap" className="text-xs sm:text-sm px-2 py-1.5">🗺️ Mind Map</TabsTrigger>
              <TabsTrigger value="graph" className="text-xs sm:text-sm px-2 py-1.5">🌐 Graph</TabsTrigger>
              <TabsTrigger value="videos" className="text-xs sm:text-sm px-2 py-1.5">🎥 Videos</TabsTrigger>
            </TabsList>

            <TabsContent value="explanation" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BookOpen className="h-5 w-5 text-primary" />
                    📘 Concept Explanation
                  </CardTitle>
                </CardHeader>
                 <CardContent>
                   <div className="prose prose-sm max-w-none text-foreground" onMouseUp={handleTextSelection}>
                     {explanation.explanation.split('\n').map((paragraph, index) => (
                       <p key={index} className="mb-4 leading-relaxed select-text">
                         {paragraph}
                       </p>
                     ))}
                   </div>
                   {selectedText && (
                     <div className="mt-4 p-3 bg-blue-50 dark:bg-blue-950/20 rounded-lg border border-blue-200 dark:border-blue-800">
                       <p className="text-sm text-blue-800 dark:text-blue-200">
                         🔍 <strong>Highlighted:</strong> "{selectedText}"
                       </p>
                       <p className="text-xs text-blue-600 dark:text-blue-400 mt-1">
                         You've selected important content for review!
                       </p>
                     </div>
                   )}
                 </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="keypoints">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Lightbulb className="h-5 w-5 text-yellow-500" />
                    🔑 Key Points Summary
                  </CardTitle>
                </CardHeader>
                 <CardContent>
                   <ul className="space-y-3">
                     {explanation.keyPoints.map((point, index) => (
                       <li key={index} className="flex items-start gap-3 p-3 bg-muted/50 rounded-lg hover:bg-muted/70 transition-colors cursor-pointer" onMouseUp={handleTextSelection}>
                         <span className="text-primary font-semibold mt-0.5">🔹</span>
                         <span className="leading-relaxed select-text">{point}</span>
                       </li>
                     ))}
                   </ul>
                   {selectedText && (
                     <div className="mt-4 p-3 bg-amber-50 dark:bg-amber-950/20 rounded-lg border border-amber-200 dark:border-amber-800">
                       <p className="text-sm text-amber-800 dark:text-amber-200">
                         ⭐ <strong>Key point selected:</strong> "{selectedText}"
                       </p>
                       <p className="text-xs text-amber-600 dark:text-amber-400 mt-1">
                         This is a crucial concept to remember!
                       </p>
                     </div>
                   )}
                 </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="tips">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="h-5 w-5 text-purple-500" />
                    🎯 Study Tips
                  </CardTitle>
                  <CardDescription className="flex items-center justify-between">
                    <span>Interactive study strategies to help you master this concept</span>
                    <Drawer>
                      <DrawerTrigger asChild>
                        <Button variant="outline" size="sm" className="ml-2">
                          <Flashlight className="h-4 w-4 mr-1" />
                          Flashcards
                        </Button>
                      </DrawerTrigger>
                      <DrawerContent>
                        <DrawerHeader>
                          <DrawerTitle>Study Flashcards for {explanation.concept}</DrawerTitle>
                          <DrawerDescription>
                            Practice with interactive flashcards based on the study tips
                          </DrawerDescription>
                        </DrawerHeader>
                        <div className="p-6">
                          {(() => {
                            const flashcards = createFlashcardsFromStudyTips();
                            if (flashcards.length === 0) return <p>No flashcards available</p>;
                            
                            const currentCard = flashcards[currentFlashcard];
                            return (
                              <div className="max-w-md mx-auto">
                                <div className="bg-gradient-to-br from-purple-50 to-indigo-50 dark:from-purple-950/20 dark:to-indigo-950/20 rounded-xl p-6 border-2 border-purple-200 dark:border-purple-800 min-h-[200px] flex flex-col justify-center">
                                  <div className="text-center">
                                    <h3 className="font-semibold text-lg mb-4 text-purple-800 dark:text-purple-200">
                                      {showFlashcardAnswer ? 'Answer' : currentCard.front}
                                    </h3>
                                    {showFlashcardAnswer ? (
                                      <p className="text-foreground leading-relaxed">{currentCard.back}</p>
                                    ) : (
                                      <Button
                                        onClick={() => setShowFlashcardAnswer(true)}
                                        className="bg-purple-600 hover:bg-purple-700"
                                      >
                                        Show Answer
                                      </Button>
                                    )}
                                  </div>
                                </div>
                                <div className="flex justify-between items-center mt-4">
                                  <Button variant="outline" onClick={handleFlashcardPrev}>
                                    Previous
                                  </Button>
                                  <span className="text-sm text-muted-foreground">
                                    {currentFlashcard + 1} of {flashcards.length}
                                  </span>
                                  <Button variant="outline" onClick={handleFlashcardNext}>
                                    Next
                                  </Button>
                                </div>
                              </div>
                            );
                          })()}
                        </div>
                      </DrawerContent>
                    </Drawer>
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {explanation.studyTips.map((tip, index) => (
                      <li key={index} className="flex items-start gap-3 p-4 bg-purple-50 dark:bg-purple-950/20 rounded-lg border border-purple-200 dark:border-purple-800 hover:bg-purple-100 dark:hover:bg-purple-950/30 transition-colors cursor-pointer" onMouseUp={handleTextSelection}>
                        <span className="h-2 w-2 bg-purple-500 rounded-full mt-2 flex-shrink-0" />
                        <span className="leading-relaxed select-text">{tip}</span>
                      </li>
                    ))}
                  </ul>
                  {selectedText && (
                    <div className="mt-4 p-3 bg-yellow-50 dark:bg-yellow-950/20 rounded-lg border border-yellow-200 dark:border-yellow-800">
                      <p className="text-sm text-yellow-800 dark:text-yellow-200">
                        💡 <strong>Selected text:</strong> "{selectedText}"
                      </p>
                      <p className="text-xs text-yellow-600 dark:text-yellow-400 mt-1">
                        This highlighted text contains important study information!
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="examples">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MessageSquare className="h-5 w-5 text-blue-500" />
                    📚 Example-Based Learning
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {explanation.examples.map((example, index) => (
                      <div key={index} className="p-4 bg-blue-50 dark:bg-blue-950/20 rounded-lg border-l-4 border-blue-500">
                        <div className="leading-relaxed">{example}</div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="related">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Network className="h-5 w-5 text-green-500" />
                    🔍 Related Concepts & Comparisons
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                    {explanation.relatedConcepts.map((related, index) => (
                      <div key={index} className="p-3 bg-muted/50 rounded-lg border cursor-pointer hover:bg-muted/70 transition-colors"
                           onClick={() => exploreRelatedConcept(related.name)}>
                        <div className="font-medium text-foreground">{related.name}</div>
                        <div className="text-sm text-muted-foreground mt-1">{related.relationship}</div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="mindmap">
              {renderMindMap()}
            </TabsContent>

            <TabsContent value="graph">
              {renderKnowledgeGraph()}
            </TabsContent>

            <TabsContent value="videos">
              {renderYouTubeVideos()}
            </TabsContent>
          </Tabs>
        </div>
      )}
    </div>
  );
}