
import { EnhancedQuizHistoryList } from './EnhancedQuizHistoryList';

// Simple wrapper to maintain backward compatibility
export function QuizHistoryList() {
  return <EnhancedQuizHistoryList />;
}
