import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  if (req.method !== 'POST') {
    return new Response('Method not allowed', { status: 405, headers: corsHeaders });
  }

  try {
    const { topic, difficulty = 'intermediate', type = 'explanation', fileContent } = await req.json();

    if (!topic) {
      return new Response(JSON.stringify({ error: 'Topic is required' }), { 
        status: 400, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Get API key from environment secrets (simpler approach)
    const apiKey = Deno.env.get('OPENAI_API_KEY');

    if (!apiKey) {
      return new Response(JSON.stringify({ 
        error: 'OpenAI API key not configured',
        details: 'Please add your OpenAI API key in the Supabase secrets'
      }), { 
        status: 400, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Build context if file content is provided
    let context = '';
    if (fileContent) {
      context = `\n\nContext from uploaded content:\n${fileContent}`;
    }

    // Create appropriate prompt based on type
    let systemPrompt = '';
    let userPrompt = '';

    switch (type) {
      case 'explanation':
        systemPrompt = `You are an expert educational AI that provides clear, comprehensive explanations of concepts. Break down complex topics into digestible parts with examples.${context}`;
        userPrompt = `Explain the concept of "${topic}" in detail. Make it suitable for ${difficulty} level understanding. Include examples and practical applications.`;
        break;
      
      case 'examples':
        systemPrompt = `You are an expert educational AI that provides practical, real-world examples to illustrate concepts clearly.${context}`;
        userPrompt = `Provide 3-5 concrete examples that demonstrate the concept of "${topic}". Make the examples relevant to ${difficulty} level understanding.`;
        break;
      
      case 'analogies':
        systemPrompt = `You are an expert educational AI that creates helpful analogies to make complex concepts easier to understand.${context}`;
        userPrompt = `Create 2-3 helpful analogies to explain the concept of "${topic}". Make the analogies appropriate for ${difficulty} level understanding.`;
        break;
      
      case 'practice':
        systemPrompt = `You are an expert educational AI that creates practice problems and exercises to help students learn concepts.${context}`;
        userPrompt = `Create 3-5 practice problems or exercises related to "${topic}". Make them suitable for ${difficulty} level. Include solutions or hints.`;
        break;
      
      default:
        systemPrompt = `You are an expert educational AI that helps students understand concepts clearly.${context}`;
        userPrompt = `Help me understand the concept of "${topic}" at a ${difficulty} level.`;
    }

    // Use only supported OpenAI models (default to gpt-4o-mini)
    const modelToUse = 'gpt-4o-mini';

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: modelToUse,
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt }
        ],
        temperature: 0.7,
        max_tokens: 2000
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('OpenAI API error:', response.status, errorText);
      
      let errorMessage = 'OpenAI API error';
      if (response.status === 401) {
        errorMessage = 'Invalid OpenAI API key - please check your configuration';
      } else if (response.status === 429) {
        errorMessage = 'OpenAI rate limit exceeded - please try again later';
      } else if (response.status === 400) {
        errorMessage = 'Invalid request to OpenAI API';
      }
      
      return new Response(JSON.stringify({ 
        error: errorMessage,
        details: errorText
      }), { 
        status: response.status, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const data = await response.json();
    const explanation = data.choices[0].message.content;

    return new Response(JSON.stringify({ 
      explanation,
      type,
      topic,
      difficulty,
      model_used: modelToUse,
      tokens_used: data.usage?.total_tokens
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('OpenAI concept learner error:', error);
    return new Response(JSON.stringify({ 
      error: 'Internal server error',
      details: error.message 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});