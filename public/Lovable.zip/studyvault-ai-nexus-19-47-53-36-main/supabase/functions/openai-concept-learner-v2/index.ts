import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { concept } = await req.json();
    
    if (!concept) {
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'Concept is required' 
      }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Get auth token
    const authHeader = req.headers.get('authorization');
    if (!authHeader) {
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'Authorization required' 
      }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const token = authHeader.replace('Bearer ', '');
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    // Verify user
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    if (authError || !user) {
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'Invalid authentication' 
      }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Get API key
    const apiKey = Deno.env.get('OPENAI_API_KEY');
    if (!apiKey) {
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'OpenAI API key not configured' 
      }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Advanced prompt structure matching your requirements
    const systemPrompt = `You are an intelligent AI tutor integrated into a study platform called StudyVault. When a user enters a topic or concept, return a complete learning bundle that includes all of the following features, formatted as a JSON object with the exact structure specified below.

Return a JSON object with these exact fields:

{
  "concept": "Main concept name",
  "explanation": "Simple, beginner-friendly explanation in 3-5 short paragraphs using plain language with real-world relevance",
  "keyPoints": ["Array of 4-7 important takeaways in bullet format with bold critical terms"],
  "studyTips": ["Array of 2-4 smart strategies for remembering or understanding this concept, including mnemonics or revision hacks"],
  "examples": ["Array of 2-3 real-world or textbook-style examples that help clarify the concept"],
  "relatedConcepts": [{"name": "Concept name", "relationship": "Explanation of how it relates or differs"}],
  "mindMap": {
    "center": "Main topic",
    "branches": [
      {
        "topic": "Definition",
        "subtopics": ["sub-concept 1", "sub-concept 2"]
      },
      {
        "topic": "Examples", 
        "subtopics": ["example 1", "example 2"]
      },
      {
        "topic": "Applications",
        "subtopics": ["application 1", "application 2"]
      },
      {
        "topic": "Key Terms",
        "subtopics": ["term 1", "term 2"]
      }
    ]
  },
  "knowledgeGraph": {
    "centralNode": "Main concept",
    "connectedNodes": ["5-7 related topics that connect to this concept"]
  },
  "youtubeSearchQuery": "Smart search phrase for high-quality educational videos (e.g., 'quantum physics explained animation tutorial')"
}

Make sure the response is educational, comprehensive, and structured for effective learning. Focus on clarity and practical understanding.`;

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: `Explain this concept comprehensively: ${concept}` }
        ],
        temperature: 0.7,
        max_tokens: 4000
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('OpenAI API error:', response.status, errorText);
      throw new Error(`OpenAI API error: ${response.status}`);
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content;

    if (!content) {
      throw new Error('No content received from OpenAI');
    }

    try {
      const parsedResult = JSON.parse(content);
      
      // Save to concept learning sessions
      await supabase
        .from('concept_learning_sessions')
        .insert({
          user_id: user.id,
          concept: concept,
          mode: 'advanced',
          response_data: parsedResult,
          tokens_used: data.usage?.total_tokens || 0,
          processing_time: Date.now() // placeholder
        });

      return new Response(JSON.stringify({ 
        success: true, 
        result: parsedResult 
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });

    } catch (parseError) {
      console.error('JSON parse error:', parseError);
      
      // Fallback: create structured response from plain text
      const fallbackResult = {
        concept: concept,
        explanation: content,
        keyPoints: [`Key aspects of ${concept}`],
        studyTips: [`Study tip for ${concept}`],
        examples: [`Example application of ${concept}`],
        relatedConcepts: [{ name: "Related topic", relationship: "Connected concept" }],
        mindMap: {
          center: concept,
          branches: [
            { topic: "Definition", subtopics: ["Basic meaning"] },
            { topic: "Examples", subtopics: ["Real-world use"] }
          ]
        },
        knowledgeGraph: {
          centralNode: concept,
          connectedNodes: ["Related topic 1", "Related topic 2"]
        },
        youtubeSearchQuery: `${concept} explained tutorial`
      };
      
      return new Response(JSON.stringify({ 
        success: true, 
        result: fallbackResult 
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

  } catch (error) {
    console.error('OpenAI concept learner error:', error);
    return new Response(JSON.stringify({ 
      success: false, 
      error: error.message || 'Internal server error' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});