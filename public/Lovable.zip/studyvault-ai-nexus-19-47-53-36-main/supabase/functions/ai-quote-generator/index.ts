import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface QuoteRequest {
  userId: string;
}

interface GeneratedQuote {
  text: string;
  category: 'motivation' | 'study' | 'jokes' | 'relaxation';
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Use service role key for database operations to bypass RLS
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    );

    const authHeader = req.headers.get('Authorization')!;
    const token = authHeader.replace('Bearer ', '');
    const { data } = await supabaseClient.auth.getUser(token);
    const user = data.user;

    if (!user) {
      throw new Error('User not authenticated');
    }

    const { userId } = await req.json() as QuoteRequest;

    if (userId !== user.id) {
      throw new Error('User ID mismatch');
    }

    console.log(`Generating quotes for user: ${userId}`);

    // Check if user already has quotes for today
    const today = new Date().toISOString().split('T')[0];
    const { data: existingQuotes } = await supabaseClient
      .from('ai_daily_quotes')
      .select('id')
      .eq('user_id', userId)
      .eq('generated_date', today)
      .limit(1);

    if (existingQuotes && existingQuotes.length > 0) {
      console.log('User already has quotes for today');
      return new Response(JSON.stringify({ 
        success: true, 
        message: 'Quotes already generated for today',
        quotesGenerated: 0 
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Get user's active AI service config
    const { data: aiConfig } = await supabaseClient
      .from('ai_service_configs')
      .select('*')
      .eq('user_id', userId)
      .eq('is_active', true)
      .single();

    if (!aiConfig) {
      console.log('No active AI service found, using fallback quotes');
      
      // Generate fallback static quotes
      const fallbackQuotes = [
        { text: "Today's efforts are tomorrow's results. Keep pushing forward!", category: 'motivation' },
        { text: "Every expert was once a beginner. Every pro was once an amateur.", category: 'study' },
        { text: "Why did the student eat his homework? Because the teacher said it was a piece of cake!", category: 'jokes' },
        { text: "Take a deep breath. You're exactly where you need to be right now.", category: 'relaxation' },
        { text: "Progress, not perfection. Every small step counts!", category: 'motivation' }
      ];

      // Save fallback quotes using database function
      for (const quote of fallbackQuotes) {
        const { data, error } = await supabaseClient
          .rpc('insert_daily_quote', {
            _user_id: userId,
            _quote_text: quote.text,
            _category: quote.category,
            _ai_service: 'fallback',
            _model_used: 'static',
            _generated_date: today
          });

        if (error) {
          console.error('Error inserting fallback quote:', error);
        } else {
          console.log('Inserted fallback quote:', data);
        }
      }

      return new Response(JSON.stringify({ 
        success: true, 
        message: 'Fallback quotes generated',
        quotesGenerated: fallbackQuotes.length,
        type: 'fallback'
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Generate AI quotes
    console.log(`Attempting to generate quotes with service: ${aiConfig.service_name}`);
    const quotes = await generateAIQuotes(aiConfig);
    console.log(`Generated ${quotes.length} quotes`);
    
    // Save quotes to database using secure function
    let successCount = 0;
    for (const quote of quotes) {
      const { data, error } = await supabaseClient
        .rpc('insert_daily_quote', {
          _user_id: userId,
          _quote_text: quote.text,
          _category: quote.category,
          _ai_service: aiConfig.service_name,
          _model_used: aiConfig.model_name || 'default',
          _generated_date: today
        });

      if (error) {
        console.error('Error inserting AI quote:', error);
      } else {
        console.log('Successfully inserted AI quote:', data);
        successCount++;
      }
    }

    if (successCount === 0) {
      throw new Error('Failed to save any AI quotes to database');
    }

    console.log(`Successfully generated and saved ${successCount}/${quotes.length} AI quotes`);

    return new Response(JSON.stringify({ 
      success: true, 
      message: 'AI quotes generated successfully',
      quotesGenerated: successCount,
      totalGenerated: quotes.length,
      type: 'ai'
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error generating quotes:', error);
    return new Response(JSON.stringify({ 
      error: error.message || 'Failed to generate quotes' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

async function generateAIQuotes(aiConfig: any): Promise<GeneratedQuote[]> {
  const categories = ['motivation', 'study', 'jokes', 'relaxation'];
  const quotes: GeneratedQuote[] = [];

  for (const category of categories) {
    try {
      const categoryQuotes = await generateQuotesForCategory(aiConfig, category);
      quotes.push(...categoryQuotes);
    } catch (error) {
      console.error(`Error generating quotes for category ${category}:`, error);
      // Add fallback quote for this category
      quotes.push({
        text: getFallbackQuote(category),
        category: category as any
      });
    }
  }

  return quotes;
}

async function generateQuotesForCategory(aiConfig: any, category: string): Promise<GeneratedQuote[]> {
  const prompts = {
    motivation: "Generate 5 short, inspiring motivational quotes for students. Focus on determination, growth mindset, and academic success. Each quote should be 15-25 words maximum.",
    study: "Generate 5 practical study-related quotes that inspire effective learning habits. Focus on study techniques, knowledge building, and academic excellence. Each quote should be 15-25 words maximum.",
    jokes: "Generate 5 light-hearted, clean study/school-related jokes or funny quotes that can make students smile during their study sessions. Keep them positive and brief (15-25 words).",
    relaxation: "Generate 5 calming, stress-relief quotes for students during study breaks. Focus on mindfulness, peace, and mental wellbeing. Each quote should be 15-25 words maximum."
  };

  let apiUrl: string;
  let headers: Record<string, string>;
  let body: any;

  if (aiConfig.service_name === 'openai') {
    apiUrl = 'https://api.openai.com/v1/chat/completions';
    headers = {
      'Authorization': `Bearer ${Deno.env.get('OPENAI_API_KEY')}`,
      'Content-Type': 'application/json',
    };
    body = {
      model: aiConfig.model_name || 'gpt-4o-mini',
      messages: [
        {
          role: 'system',
          content: 'You are a helpful assistant that generates inspiring quotes for students. Return only the quotes, one per line, without numbering or extra formatting.'
        },
        {
          role: 'user',
          content: prompts[category as keyof typeof prompts]
        }
      ],
      max_tokens: 300,
      temperature: 0.8
    };
  } else if (aiConfig.service_name === 'gemini') {
    apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/${aiConfig.model_name || 'gemini-1.5-flash'}:generateContent?key=${Deno.env.get('GEMINI_API_KEY')}`;
    headers = {
      'Content-Type': 'application/json',
    };
    body = {
      contents: [{
        parts: [{
          text: prompts[category as keyof typeof prompts] + "\n\nReturn only the quotes, one per line, without numbering or extra formatting."
        }]
      }]
    };
  } else {
    throw new Error(`Unsupported AI service: ${aiConfig.service_name}`);
  }

  const response = await fetch(apiUrl, {
    method: 'POST',
    headers,
    body: JSON.stringify(body),
  });

  if (!response.ok) {
    throw new Error(`AI API error: ${response.status} ${response.statusText}`);
  }

  const data = await response.json();
  
  let quotesText: string;
  if (aiConfig.service_name === 'openai') {
    quotesText = data.choices[0].message.content;
  } else if (aiConfig.service_name === 'gemini') {
    quotesText = data.candidates[0].content.parts[0].text;
  } else {
    throw new Error('Unknown AI service response format');
  }

  // Parse quotes from response
  const quoteLines = quotesText
    .split('\n')
    .map(line => line.trim())
    .filter(line => line.length > 10 && !line.match(/^\d+\.?/)) // Remove numbering and very short lines
    .slice(0, 5); // Limit to 5 quotes per category

  return quoteLines.map(text => ({
    text: text.replace(/^["']|["']$/g, ''), // Remove quotes if present
    category: category as any
  }));
}

function getFallbackQuote(category: string): string {
  const fallbacks = {
    motivation: "Success is the sum of small efforts repeated day in and day out.",
    study: "The beautiful thing about learning is that no one can take it away from you.",
    jokes: "Why did the math book look so sad? Because it had too many problems!",
    relaxation: "Take a deep breath and remember: you're doing better than you think."
  };
  
  return fallbacks[category as keyof typeof fallbacks] || "Keep going, you're doing great!";
}